package com.example.activityworld.network

enum class ApiStatus {
    LOADING,
    ERROR,
    DONE
}