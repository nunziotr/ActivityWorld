package com.example.activityworld.booking.model

import com.example.activityworld.home.model.FieldAvailability

data class Attributions(
    val booking: Long,
    val availability: Long,
    val field: Long
)
