package com.example.activityworld.home.constant

enum class AvailabilityStatus {
    AVAILABLE,
    EXPIRED,
    RESERVED
}